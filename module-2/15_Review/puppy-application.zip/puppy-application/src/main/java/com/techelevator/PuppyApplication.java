package com.techelevator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PuppyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PuppyApplication.class, args);
	}

}
